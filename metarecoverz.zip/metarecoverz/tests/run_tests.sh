#!/usr/bin/env bash
# tests/run_tests.sh — MetaRecoverX automated test suite
# Validates the build, pipeline, output formats, and known bug fixes.
# Usage: ./tests/run_tests.sh

set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
PASSED=0
FAILED=0

pass() { echo "  ✓ $1"; ((PASSED++)) || true; }
fail() { echo "  ✗ $1"; ((FAILED++)) || true; }

echo "╔══════════════════════════════════════════╗"
echo "║     MetaRecoverX Test Suite              ║"
echo "╚══════════════════════════════════════════╝"
echo ""

# ─── Test: Build ──────────────────────────────────────────
echo "▸ Build"
if "$ROOT/scripts/build.sh" >/dev/null 2>&1; then
    pass "Build successful"
else
    fail "Build failed"
fi

# ─── Test: Binary existence ───────────────────────────────
echo ""
echo "▸ Binary existence"
for bin in xfs_scan btrfs_scan reconstruct_csv recover_csv; do
    if [[ -x "$ROOT/build/$bin" ]]; then
        pass "$bin exists and is executable"
    else
        fail "$bin missing or not executable"
    fi
done

# ─── Test: --help flags ──────────────────────────────────
echo ""
echo "▸ Scanner --help flags"
for bin in xfs_scan btrfs_scan; do
    if "$ROOT/build/$bin" --help 2>&1 | grep -qi "usage"; then
        pass "$bin --help works"
    else
        fail "$bin --help broken"
    fi
done

# ─── Test: Demo pipeline ─────────────────────────────────
echo ""
echo "▸ Demo pipeline"
# Clean outputs
rm -f "$ROOT"/artifacts/*.csv "$ROOT"/artifacts/*.json "$ROOT/report.csv" 2>/dev/null || true
rm -f "$ROOT"/recovered/* 2>/dev/null || true

if "$ROOT/scripts/metarecoverx.sh" demo >/dev/null 2>&1; then
    pass "Demo pipeline completed"
else
    fail "Demo pipeline failed"
fi

# ─── Test: Output file existence ─────────────────────────
echo ""
echo "▸ Output files"
for f in artifacts/xfs_scan.csv artifacts/btrfs_scan.csv artifacts/metadata.csv artifacts/metadata.json artifacts/acquire.json report.csv; do
    if [[ -f "$ROOT/$f" ]]; then
        pass "$f exists"
    else
        fail "$f missing"
    fi
done

# ─── Test: CSV header validation ─────────────────────────
echo ""
echo "▸ CSV format validation"
expected_scanner="fs,inode,path,size,uid,gid,mode,atime,mtime,ctime,extents"
expected_meta="global_id,fs,path,size,uid,gid,mode,atime,mtime,ctime,extents,recovery_plan"

actual_xfs=$(head -1 "$ROOT/artifacts/xfs_scan.csv" | tr -d '\r')
actual_btrfs=$(head -1 "$ROOT/artifacts/btrfs_scan.csv" | tr -d '\r')
actual_meta=$(head -1 "$ROOT/artifacts/metadata.csv" | tr -d '\r')

if [[ "$actual_xfs" == "$expected_scanner" ]]; then
    pass "xfs_scan.csv header correct"
else
    fail "xfs_scan.csv header: expected '$expected_scanner', got '$actual_xfs'"
fi

if [[ "$actual_btrfs" == "$expected_scanner" ]]; then
    pass "btrfs_scan.csv header correct"
else
    fail "btrfs_scan.csv header: expected '$expected_scanner', got '$actual_btrfs'"
fi

if [[ "$actual_meta" == "$expected_meta" ]]; then
    pass "metadata.csv header correct"
else
    fail "metadata.csv header: expected '$expected_meta', got '$actual_meta'"
fi

# ─── Test: JSON validity ─────────────────────────────────
echo ""
echo "▸ JSON format validation"
for jf in artifacts/metadata.json artifacts/acquire.json; do
    content=$(cat "$ROOT/$jf" | tr -d '\r\n\t ')
    if [[ "$content" == "{"* && "$content" == *"}" ]]; then
        pass "$jf is valid JSON structure"
    else
        fail "$jf is not valid JSON"
    fi
done

# ─── Test: No double-prefix bug ──────────────────────────
echo ""
echo "▸ Bug regression: no double-prefix"
if grep -q "xfs-xfs-\|btrfs-btrfs-" "$ROOT/artifacts/metadata.csv" 2>/dev/null; then
    fail "Double-prefix found in metadata.csv (xfs-xfs- or btrfs-btrfs-)"
else
    pass "No double-prefix in global_id"
fi

# ─── Test: Real timestamps (not "now") ───────────────────
echo ""
echo "▸ Bug regression: real timestamps"
if grep -q '"generated_at": "now"' "$ROOT/artifacts/metadata.json" 2>/dev/null; then
    fail "generated_at is still 'now' in metadata.json"
else
    pass "generated_at has real ISO 8601 timestamp"
fi

# ─── Test: recovery_plan column ──────────────────────────
echo ""
echo "▸ Feature check: recovery_plan column"
if head -1 "$ROOT/artifacts/metadata.csv" | grep -q "recovery_plan"; then
    pass "recovery_plan column present in metadata.csv"
else
    fail "recovery_plan column missing from metadata.csv"
fi

# ─── Test: Recovered files exist ─────────────────────────
echo ""
echo "▸ Recovered files"
count=$(ls "$ROOT/recovered/" 2>/dev/null | wc -l)
if [[ "$count" -gt 0 ]]; then
    pass "Recovered $count file(s) in recovered/"
else
    fail "No recovered files found"
fi

# ─── Test: Scanner CSV has data rows ─────────────────────
echo ""
echo "▸ Data content check"
xfs_lines=$(wc -l < "$ROOT/artifacts/xfs_scan.csv" | tr -d ' ')
btrfs_lines=$(wc -l < "$ROOT/artifacts/btrfs_scan.csv" | tr -d ' ')
meta_lines=$(wc -l < "$ROOT/artifacts/metadata.csv" | tr -d ' ')

if [[ "$xfs_lines" -ge 2 ]]; then
    pass "xfs_scan.csv has $((xfs_lines - 1)) data row(s)"
else
    fail "xfs_scan.csv has no data rows"
fi

if [[ "$btrfs_lines" -ge 2 ]]; then
    pass "btrfs_scan.csv has $((btrfs_lines - 1)) data row(s)"
else
    fail "btrfs_scan.csv has no data rows"
fi

if [[ "$meta_lines" -ge 2 ]]; then
    pass "metadata.csv has $((meta_lines - 1)) data row(s)"
else
    fail "metadata.csv has no data rows"
fi

# ─── Test: Script help ───────────────────────────────────
echo ""
echo "▸ Script validation"
if "$ROOT/scripts/metarecoverx.sh" --help 2>&1 | grep -qi "usage\|metarecoverx"; then
    pass "metarecoverx.sh --help works"
else
    fail "metarecoverx.sh --help broken"
fi

if bash -n "$ROOT/scripts/menu.sh" 2>/dev/null; then
    pass "menu.sh syntax valid"
else
    fail "menu.sh has syntax errors"
fi

if bash -n "$ROOT/scripts/detect_usb.sh" 2>/dev/null; then
    pass "detect_usb.sh syntax valid"
else
    fail "detect_usb.sh has syntax errors"
fi

# ─── Summary ─────────────────────────────────────────────
echo ""
echo "══════════════════════════════════════════════"
echo "  Results: $PASSED passed, $FAILED failed"
echo "══════════════════════════════════════════════"
if [[ "$FAILED" -eq 0 ]]; then
    echo "  ✓ All tests passed!"
    exit 0
else
    echo "  ✗ Some tests failed."
    exit 1
fi
