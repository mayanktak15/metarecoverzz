#!/usr/bin/env bash
# scripts/generate_report.sh — Generate a human-readable recovery report
# Usage: ./scripts/generate_report.sh [--output report.txt]
# Reads: artifacts/metadata.csv, artifacts/acquire.json
# Writes: report.txt (or specified file)

set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
ART_DIR="$ROOT_DIR/artifacts"
REC_DIR="$ROOT_DIR/recovered"

OUTPUT="${1:-$ROOT_DIR/report.txt}"
# Handle --output flag
if [[ "${1:-}" == "--output" ]] && [[ -n "${2:-}" ]]; then
    OUTPUT="$2"
fi

CSV="$ART_DIR/metadata.csv"
ACQ="$ART_DIR/acquire.json"

if [[ ! -f "$CSV" ]]; then
    echo "error: $CSV not found. Run a pipeline first." >&2
    exit 1
fi

{
    echo "╔══════════════════════════════════════════════════════════╗"
    echo "║             MetaRecoverX Recovery Report                ║"
    echo "║   Forensic Data Recovery — XFS & Btrfs Filesystems      ║"
    echo "╚══════════════════════════════════════════════════════════╝"
    echo ""
    echo "  Report generated: $(date -u +"%Y-%m-%dT%H:%M:%SZ")"
    echo ""

    # ── Acquisition info ──────────────────────────────────────────
    if [[ -f "$ACQ" ]]; then
        echo "─── Acquisition Information ──────────────────────────────"
        local_img=$(grep '"image"' "$ACQ" 2>/dev/null | sed 's/.*: *"//;s/".*//' || echo "unknown")
        local_hash=$(grep '"value"' "$ACQ" 2>/dev/null | sed 's/.*: *"//;s/".*//' || echo "unknown")
        local_size=$(grep '"size"' "$ACQ" 2>/dev/null | sed 's/.*: *//;s/[,}].*//' || echo "0")
        local_time=$(grep '"generated_at"' "$ACQ" 2>/dev/null | sed 's/.*: *"//;s/".*//' || echo "unknown")

        echo "  Image path:     $local_img"
        if [[ "$local_size" =~ ^[0-9]+$ ]] && [[ "$local_size" -gt 0 ]]; then
            local_mb=$((local_size / 1048576))
            echo "  Image size:     $local_size bytes ($local_mb MiB)"
        fi
        echo "  SHA-256 hash:   $local_hash"
        echo "  Acquired at:    $local_time"

        if [[ -f "$ART_DIR/hash.txt" ]]; then
            echo "  Hash file:      $ART_DIR/hash.txt"
        fi
        echo ""
    fi

    # ── Recovery summary ──────────────────────────────────────────
    echo "─── Recovery Summary ───────────────────────────────────────"
    total_files=0
    total_size=0
    xfs_count=0
    btrfs_count=0
    carve_count=0
    skip_count=0

    while IFS=, read -r gid fs path size uid gid_f mode atime mtime ctime extents plan rest; do
        [[ "$gid" == "global_id" ]] && continue
        ((total_files++)) || true
        if [[ -n "$size" && "$size" =~ ^[0-9]+$ ]]; then
            ((total_size += size)) || true
        fi
        case "$fs" in
            xfs)   ((xfs_count++))   || true ;;
            btrfs) ((btrfs_count++)) || true ;;
        esac
        case "$plan" in
            carve) ((carve_count++)) || true ;;
            skip)  ((skip_count++))  || true ;;
        esac
    done < "$CSV"

    size_mb=$((total_size / 1048576))
    size_kb=$((total_size / 1024))
    echo "  Total entries found:    $total_files"
    if [[ "$size_mb" -gt 0 ]]; then
        echo "  Total data size:        $total_size bytes ($size_mb MiB)"
    else
        echo "  Total data size:        $total_size bytes ($size_kb KiB)"
    fi
    echo "  XFS entries:            $xfs_count"
    echo "  Btrfs entries:          $btrfs_count"
    echo "  Recovery plan: carve    $carve_count"
    echo "  Recovery plan: skip     $skip_count"
    echo ""

    # ── Recovered files ───────────────────────────────────────────
    echo "─── Recovered Files ────────────────────────────────────────"
    if [[ -d "$REC_DIR" ]] && ls "$REC_DIR"/* >/dev/null 2>&1; then
        rec_count=$(ls -1 "$REC_DIR" | wc -l)
        rec_total=$(du -sh "$REC_DIR" 2>/dev/null | awk '{print $1}')
        echo "  Files recovered:  $rec_count ($rec_total total)"
        echo ""
        printf "  %-35s %10s\n" "Filename" "Size"
        printf "  %-35s %10s\n" "───────────────────────────────────" "──────────"
        ls -lh "$REC_DIR"/ 2>/dev/null | tail -n +2 | while read -r perms _ _ _ fsize _ _ _ fname rest; do
            [[ -n "$fname" ]] && printf "  %-35s %10s\n" "$fname" "$fsize"
        done
    else
        echo "  (no files recovered)"
    fi
    echo ""

    # ── Detailed metadata ─────────────────────────────────────────
    echo "─── Metadata Details (first 20 entries) ──────────────────"
    if command -v column >/dev/null 2>&1; then
        head -21 "$CSV" | column -t -s, 2>/dev/null || head -21 "$CSV"
    else
        head -21 "$CSV"
    fi

    lines=$(wc -l < "$CSV")
    if [[ "$lines" -gt 21 ]]; then
        echo ""
        echo "  ... and $((lines - 21)) more entries (see full CSV)"
    fi
    echo ""

    # ── Output files ──────────────────────────────────────────────
    echo "─── Output Locations ───────────────────────────────────────"
    echo "  Metadata CSV:    $CSV"
    echo "  Metadata JSON:   $ART_DIR/metadata.json"
    echo "  Acquisition:     $ACQ"
    echo "  Recovered files: $REC_DIR/"
    echo "  Report CSV:      $ROOT_DIR/report.csv"
    echo "  This report:     $OUTPUT"
    echo ""
    echo "══════════════════════════════════════════════════════════"

} | tee "$OUTPUT"

echo ""
echo "Report saved to: $OUTPUT"
