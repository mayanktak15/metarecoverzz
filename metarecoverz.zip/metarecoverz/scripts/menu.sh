#!/usr/bin/env bash
set -euo pipefail

# MetaRecoverX interactive TTY menu
# Provides a key-driven interface for all major operations

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

while true; do
  clear || true
  echo "╔════════════════════════════════════════╗"
  echo "║        MetaRecoverX  Menu              ║"
  echo "║  Forensic Data Recovery Tool           ║"
  echo "╚════════════════════════════════════════╝"
  echo ""
  echo "  [1] Detect USB storage devices"
  echo "  [2] Run demo pipeline (dummy.img)"
  echo "  [3] Full pipeline on disk image"
  echo "  [4] USB forensic recovery pipeline"
  echo "  [5] View last recovery report"
  echo "  [6] Clean all outputs"
  echo "  [q] Quit"
  echo ""
  read -rp "  Select an option: " choice

  case "${choice}" in
    1)
      echo ""
      echo "═══ Detecting USB storage devices ═══"
      echo ""
      bash "${ROOT_DIR}/scripts/metarecoverx.sh" detect-usb || true
      echo ""
      read -rp "Press Enter to return to menu..." _pause
      ;;
    2)
      echo ""
      echo "═══ Running demo pipeline (dummy.img) ═══"
      echo ""
      bash "${ROOT_DIR}/scripts/metarecoverx.sh" demo || true
      echo ""
      read -rp "Press Enter to return to menu..." _pause
      ;;
    3)
      echo ""
      read -rp "  Enter disk image path: " img_path
      if [[ -z "$img_path" ]]; then
        echo "  No path provided."
      elif [[ ! -f "$img_path" ]]; then
        echo "  Error: file not found: $img_path"
      else
        echo ""
        echo "═══ Running full pipeline on: $img_path ═══"
        echo ""
        bash "${ROOT_DIR}/scripts/metarecoverx.sh" pipeline --image "$img_path" || true
      fi
      echo ""
      read -rp "Press Enter to return to menu..." _pause
      ;;
    4)
      echo ""
      echo "  Available USB devices:"
      bash "${ROOT_DIR}/scripts/metarecoverx.sh" detect-usb 2>/dev/null || true
      echo ""
      read -rp "  Enter device path (e.g. /dev/sdb): " dev_path
      if [[ -z "$dev_path" ]]; then
        echo "  No device provided."
      elif [[ ! -e "$dev_path" ]]; then
        echo "  Error: device not found: $dev_path"
      else
        echo ""
        echo "  ⚠  WARNING: This will read from $dev_path"
        read -rp "  Are you sure? (y/N): " confirm
        if [[ "${confirm,,}" == "y" ]]; then
          echo ""
          echo "═══ Running USB forensic pipeline on: $dev_path ═══"
          echo ""
          sudo bash "${ROOT_DIR}/scripts/metarecoverx.sh" pipeline-usb --device "$dev_path" || true
        else
          echo "  Cancelled."
        fi
      fi
      echo ""
      read -rp "Press Enter to return to menu..." _pause
      ;;
    5)
      echo ""
      echo "═══ Last Recovery Report ═══"
      echo ""
      if [[ -f "${ROOT_DIR}/report.csv" ]]; then
        column -t -s, "${ROOT_DIR}/report.csv" 2>/dev/null || cat "${ROOT_DIR}/report.csv"
        echo ""
        echo "  File: ${ROOT_DIR}/report.csv"
        echo "  Recovered files: ${ROOT_DIR}/recovered/"
        if [[ -d "${ROOT_DIR}/recovered" ]]; then
          echo "  Contents:"
          ls -lh "${ROOT_DIR}/recovered/" 2>/dev/null || echo "    (empty)"
        fi
      else
        echo "  No report found. Run a pipeline first."
      fi
      echo ""
      read -rp "Press Enter to return to menu..." _pause
      ;;
    6)
      echo ""
      read -rp "  Clean all outputs (artifacts, recovered, report)? (y/N): " confirm
      if [[ "${confirm,,}" == "y" ]]; then
        rm -rf "${ROOT_DIR}/artifacts/"* "${ROOT_DIR}/recovered/"* "${ROOT_DIR}/report.csv" 2>/dev/null || true
        echo "  Cleaned."
      else
        echo "  Cancelled."
      fi
      echo ""
      read -rp "Press Enter to return to menu..." _pause
      ;;
    q|Q)
      echo ""
      echo "  Exiting MetaRecoverX menu."
      exit 0
      ;;
    *)
      echo "  Unknown option: ${choice}"
      sleep 1
      ;;
  esac

done
