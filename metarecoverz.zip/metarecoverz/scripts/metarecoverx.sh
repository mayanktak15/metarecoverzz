#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
ART_DIR="$ROOT_DIR/artifacts"
REC_DIR="$ROOT_DIR/recovered"
BUILD_DIR="$ROOT_DIR/build"

ensure_dirs() {
  mkdir -p "$ART_DIR" "$REC_DIR" "$BUILD_DIR"
}

print_usage() {
  cat <<'USAGE'
MetaRecoverX (offline, Bash wrapper)

Usage:
  scripts/metarecoverx.sh build
  scripts/metarecoverx.sh acquire --image <path>
  scripts/metarecoverx.sh scan xfs    --image <path> [--format csv|json]
  scripts/metarecoverx.sh scan btrfs  --image <path> [--format csv|json]
  scripts/metarecoverx.sh reconstruct [--out artifacts/metadata.json] [--csv-out artifacts/metadata.csv] [inputs.csv ...]
  scripts/metarecoverx.sh recover --image <path> [--plan artifacts/metadata.csv] [--out recovered]
  scripts/metarecoverx.sh pipeline --image <path>
  scripts/metarecoverx.sh detect-usb
  scripts/metarecoverx.sh pipeline-usb --device /dev/sdX [--direct]
  scripts/metarecoverx.sh report
  scripts/metarecoverx.sh demo [--image dummy.img]
  scripts/metarecoverx.sh test

Commands:
  build        Build all C++ binaries (uses CMake if available, else g++)
  acquire      Write acquire.json with size + sha256 for the image
  scan         Run xfs_scan or btrfs_scan producing CSV or JSON
  reconstruct  Merge scan CSVs into metadata.json + metadata.csv
  recover      Carve extents from image into recovered/*.bin
  pipeline     Build + acquire + scan (xfs,btrfs) + reconstruct + recover + report (Ubuntu TTY, offline)
  detect-usb   List connected USB storage devices
  pipeline-usb Forensically image a USB/removable device then run the full pipeline
               Use --direct to skip dd imaging and scan the device directly (faster)
  report       Generate a human-readable recovery report from artifacts/
  demo         Full pipeline on a small image (creates one if missing)
  test         Run the automated test suite
USAGE
}

resolve_path() {
  local p="$1"
  if command -v readlink >/dev/null 2>&1; then
    readlink -f "$p" 2>/dev/null || printf '%s' "$p"
  elif command -v realpath >/dev/null 2>&1; then
    realpath "$p" 2>/dev/null || printf '%s' "$p"
  else
    printf '%s' "$p"
  fi
}

cmd_build() {
  ( cd "$ROOT_DIR" && ./scripts/build.sh )
}

cmd_acquire() {
  local image=""
  while [[ $# -gt 0 ]]; do
    case "$1" in
      --image) image="$2"; shift 2;;
      --help|-h) print_usage; return 0;;
      *) echo "unknown arg: $1" >&2; return 2;;
    esac
  done
  [[ -n "$image" ]] || { echo "--image is required" >&2; return 2; }
  [[ -f "$image" || -b "$image" ]] || { echo "image not found: $image" >&2; return 1; }
  ensure_dirs
  local size hash abs
  size=$(stat -c%s "$image")
  if command -v sha256sum >/dev/null 2>&1; then
    hash=$(sha256sum "$image" | awk '{print $1}')
  else
    echo "sha256sum not found" >&2; return 1
  fi
  abs=$(resolve_path "$image")
  cat > "$ART_DIR/acquire.json" <<JSON
{
  "schema": "metarecoverx.acquire.v1",
  "image": "$abs",
  "generated_at": "now",
  "size": $size,
  "hash": { "algo": "sha256", "value": "$hash" },
  "notes": ""
}
JSON
  echo "wrote $ART_DIR/acquire.json"
}

cmd_scan() {
  local fs="" image="" format="csv"
  [[ $# -ge 1 ]] || { print_usage; return 2; }
  fs="$1"; shift || true
  while [[ $# -gt 0 ]]; do
    case "$1" in
      --image) image="$2"; shift 2;;
      --format) format="$2"; shift 2;;
      --help|-h) print_usage; return 0;;
      *) echo "unknown arg: $1" >&2; return 2;;
    esac
  done
  [[ -n "$image" ]] || { echo "--image is required" >&2; return 2; }
  [[ -f "$image" || -b "$image" ]] || { echo "image not found: $image" >&2; return 1; }
  ensure_dirs
  cmd_build >/dev/null
  case "$fs" in
    xfs)
      if [[ "$format" == "csv" ]]; then
        "$BUILD_DIR/xfs_scan" --image "$image" --format csv > "$ART_DIR/xfs_scan.csv"
        echo "wrote $ART_DIR/xfs_scan.csv"
      else
        "$BUILD_DIR/xfs_scan" --image "$image" > "$ART_DIR/xfs_scan.json"
        echo "wrote $ART_DIR/xfs_scan.json"
      fi
      ;;
    btrfs)
      if [[ "$format" == "csv" ]]; then
        "$BUILD_DIR/btrfs_scan" --image "$image" --format csv > "$ART_DIR/btrfs_scan.csv"
        echo "wrote $ART_DIR/btrfs_scan.csv"
      else
        "$BUILD_DIR/btrfs_scan" --image "$image" > "$ART_DIR/btrfs_scan.json"
        echo "wrote $ART_DIR/btrfs_scan.json"
      fi
      ;;
    *) echo "unknown fs: $fs (use xfs|btrfs)" >&2; return 2;;
  esac
}

cmd_reconstruct() {
  local out_json="$ART_DIR/metadata.json" out_csv="$ART_DIR/metadata.csv"
  local inputs=()
  while [[ $# -gt 0 ]]; do
    case "$1" in
      --out) out_json="$2"; shift 2;;
      --csv-out) out_csv="$2"; shift 2;;
      --help|-h) print_usage; return 0;;
      *) inputs+=("$1"); shift;;
    esac
  done
  ensure_dirs
  if [[ ${#inputs[@]} -eq 0 ]]; then
    [[ -f "$ART_DIR/xfs_scan.csv" ]] && inputs+=("$ART_DIR/xfs_scan.csv")
    [[ -f "$ART_DIR/btrfs_scan.csv" ]] && inputs+=("$ART_DIR/btrfs_scan.csv")
  fi
  [[ ${#inputs[@]} -gt 0 ]] || { echo "no input CSVs provided" >&2; return 2; }
  cmd_build >/dev/null
  "$BUILD_DIR/reconstruct_csv" --out "$out_json" --csv-out "$out_csv" "${inputs[@]}"
  echo "wrote $out_json"
  echo "wrote $out_csv"
}

cmd_recover() {
  local image="" plan="$ART_DIR/metadata.csv" out="$REC_DIR"
  while [[ $# -gt 0 ]]; do
    case "$1" in
      --image) image="$2"; shift 2;;
      --plan) plan="$2"; shift 2;;
      --out) out="$2"; shift 2;;
      --help|-h) print_usage; return 0;;
      *) echo "unknown arg: $1" >&2; return 2;;
    esac
  done
  [[ -n "$image" ]] || { echo "--image is required" >&2; return 2; }
  [[ -f "$image" || -b "$image" ]] || { echo "image not found: $image" >&2; return 1; }
  [[ -f "$plan" ]] || { echo "plan not found: $plan" >&2; return 1; }
  ensure_dirs
  cmd_build >/dev/null
  "$BUILD_DIR/recover_csv" --image "$image" --plan "$plan" --out "$out"
}

cmd_pipeline() {
  local image=""
  while [[ $# -gt 0 ]]; do
    case "$1" in
      --image) image="$2"; shift 2;;
      --help|-h) print_usage; return 0;;
      *) echo "unknown arg: $1" >&2; return 2;;
    esac
  done
  [[ -n "$image" ]] || { echo "--image is required" >&2; return 2; }
  [[ -f "$image" || -b "$image" ]] || { echo "image not found: $image" >&2; return 1; }

  ensure_dirs
  echo "[1/5] Building binaries..."; cmd_build
  echo "[2/5] Acquiring image info..."; cmd_acquire --image "$image"
  echo "[3/6] Scanning filesystems (XFS + Btrfs in parallel)..."
  cmd_scan xfs   --image "$image" --format csv &
  local pid_xfs=$!
  cmd_scan btrfs --image "$image" --format csv &
  local pid_btrfs=$!
  wait "$pid_xfs" "$pid_btrfs"
  echo "[4/5] Reconstructing metadata..."
  cmd_reconstruct
  echo "[5/6] Recovering file data..."
  cmd_recover --image "$image"
  cp "$ART_DIR/metadata.csv" "$ROOT_DIR/report.csv" 2>/dev/null || true
  echo "[6/6] Generating report..."
  cmd_report
  echo "Pipeline complete. See artifacts/, recovered/, report.csv, and report.txt"
}

# ---------------------------------------------------------------------------
# detect-usb: print USB storage devices (wraps detect_usb.sh)
# ---------------------------------------------------------------------------
cmd_detect_usb() {
  local script="$ROOT_DIR/scripts/detect_usb.sh"
  if [[ -f "$script" ]]; then
    bash "$script"
  else
    # inline fallback if the helper script is missing
    if ! command -v lsblk >/dev/null 2>&1; then
      echo "error: lsblk not found (install util-linux)" >&2; return 1
    fi
    echo "NAME  TRAN  SIZE  MOUNTPOINT"
    echo "----  ----  ----  ----------"
    lsblk -o NAME,TRAN,SIZE,MOUNTPOINT -n 2>/dev/null \
      | awk '$2 == "usb" { printf "%-6s %-5s %-6s %s\n", $1, $2, $3, ($4==""?"":$4) }'
  fi
}

# ---------------------------------------------------------------------------
# detect_fs: use blkid to auto-detect filesystem on an image file
#   prints "xfs", "btrfs", or "unknown"
# ---------------------------------------------------------------------------
detect_fs() {
  local image="$1"
  if command -v blkid >/dev/null 2>&1; then
    local fstype
    fstype=$(blkid -o value -s TYPE "$image" 2>/dev/null || true)
    case "$fstype" in
      xfs)   echo "xfs";   return;;
      btrfs) echo "btrfs"; return;;
    esac
  fi
  echo "unknown"
}

# ---------------------------------------------------------------------------
# pipeline-usb: forensic image from a USB/removable device → full pipeline
# ---------------------------------------------------------------------------
cmd_pipeline_usb() {
  local device="" direct=false
  while [[ $# -gt 0 ]]; do
    case "$1" in
      --device) device="$2"; shift 2;;
      --direct) direct=true; shift;;
      --help|-h) print_usage; return 0;;
      *) echo "unknown arg: $1" >&2; return 2;;
    esac
  done

  [[ -n "$device" ]] || { echo "--device is required (e.g. --device /dev/sdb)" >&2; return 2; }
  [[ -e "$device" ]]  || { echo "device not found: $device" >&2; return 1; }

  ensure_dirs

  # Step 1 — list USB devices for reference
  echo "[pipeline-usb] Connected USB devices:"
  cmd_detect_usb || true
  echo ""

  # Step 2 — build C++ tools
  echo "[1] Building binaries..."
  cmd_build

  local scan_target="$device"

  if [[ "$direct" == true ]]; then
    # ── DIRECT MODE: skip dd, scan device directly ──────────────────────
    echo ""
    echo "[direct] Scanning device $device directly (no dd copy)..."
    echo "         This is much faster but does not create a forensic image."
    echo ""

    # Generate acquire.json from device
    local dev_size
    dev_size=$(blockdev --getsize64 "$device" 2>/dev/null || echo 0)
    cat > "$ART_DIR/acquire.json" <<JSON
{
  "schema": "metarecoverx.acquire.v1",
  "image": "$device",
  "generated_at": "$(date -u +"%Y-%m-%dT%H:%M:%SZ")",
  "size": $dev_size,
  "mode": "direct",
  "note": "Scanned device directly without forensic imaging"
}
JSON
    echo "wrote $ART_DIR/acquire.json"
  else
    # ── IMAGE MODE: full forensic dd + hash ─────────────────────────────
    local img_name
    img_name="usb_$(basename "$device")_$(date +%Y%m%d_%H%M%S).img"
    local img_path="$ART_DIR/$img_name"

    echo "[2] Acquiring forensic image from $device ..."
    echo "    destination: $img_path"
    echo "    (use --direct to skip this step and scan device directly)"
    if ! command -v dd >/dev/null 2>&1; then
      echo "error: dd not found" >&2; return 1
    fi
    dd if="$device" of="$img_path" bs=4M status=progress conv=noerror,sync
    echo "dd complete."

    echo "[3] Generating SHA256 hash..."
    if ! command -v sha256sum >/dev/null 2>&1; then
      echo "error: sha256sum not found" >&2; return 1
    fi
    sha256sum "$img_path" > "$ART_DIR/hash.txt"
    echo "    written: $ART_DIR/hash.txt"
    cat "$ART_DIR/hash.txt"

    echo "[4] Recording acquisition metadata..."
    cmd_acquire --image "$img_path"

    scan_target="$img_path"
  fi

  # ── Detect filesystem type and scan ────────────────────────────────
  echo "[5] Detecting filesystem and scanning..."
  local fstype
  fstype=$(detect_fs "$scan_target")
  echo "    detected filesystem: $fstype"

  case "$fstype" in
    xfs)
      cmd_scan xfs   --image "$scan_target" --format csv
      ;;
    btrfs)
      cmd_scan btrfs --image "$scan_target" --format csv
      ;;
    *)
      echo "    filesystem unknown or undetectable; scanning as both XFS and Btrfs..."
      cmd_scan xfs   --image "$scan_target" --format csv
      cmd_scan btrfs --image "$scan_target" --format csv
      ;;
  esac

  # ── Reconstruct + recover ──────────────────────────────────────────
  echo "[6] Reconstructing metadata and recovering files..."
  cmd_reconstruct
  cmd_recover --image "$scan_target"

  cp "$ART_DIR/metadata.csv" "$ROOT_DIR/report.csv" 2>/dev/null || true

  echo "[7] Generating report..."
  cmd_report

  echo ""
  echo "pipeline-usb complete."
  if [[ "$direct" == true ]]; then
    echo "  Mode           : DIRECT (no forensic image created)"
    echo "  Device scanned : $device"
  else
    echo "  Mode           : FORENSIC IMAGE"
    echo "  Forensic image : $scan_target"
    echo "  SHA256 hash    : $ART_DIR/hash.txt"
  fi
  echo "  Artifacts      : $ART_DIR/"
  echo "  Recovered files: $REC_DIR/"
  echo "  Report CSV     : $ROOT_DIR/report.csv"
  echo "  Report         : $ROOT_DIR/report.txt"
}

cmd_demo() {
  local image="dummy.img"
  while [[ $# -gt 0 ]]; do
    case "$1" in
      --image) image="$2"; shift 2;;
      --help|-h) print_usage; return 0;;
      *) echo "unknown arg: $1" >&2; return 2;;
    esac
  done
  ensure_dirs
  cmd_build
  if [[ ! -f "$image" ]]; then
    dd if=/dev/zero of="$image" bs=1M count=1 status=none
  fi
  "$0" acquire --image "$image"
  "$0" scan xfs --image "$image" --format csv
  "$0" scan btrfs --image "$image" --format csv
  "$0" reconstruct
  "$0" recover --image "$image"
  cp "$ART_DIR/metadata.csv" "$ROOT_DIR/report.csv"
  echo "Demo complete. See artifacts/, recovered/, and report.csv"
}

# ---------------------------------------------------------------------------
# report: generate human-readable report
# ---------------------------------------------------------------------------
cmd_report() {
  local script="$ROOT_DIR/scripts/generate_report.sh"
  if [[ -f "$script" ]]; then
    bash "$script"
  else
    echo "error: generate_report.sh not found" >&2; return 1
  fi
}

# ---------------------------------------------------------------------------
# test: run automated test suite
# ---------------------------------------------------------------------------
cmd_test() {
  local script="$ROOT_DIR/tests/run_tests.sh"
  if [[ -f "$script" ]]; then
    bash "$script"
  else
    echo "error: tests/run_tests.sh not found" >&2; return 1
  fi
}

main() {
  local cmd="${1:-}"; shift || true
  case "$cmd" in
    build) cmd_build "$@";;
    acquire) cmd_acquire "$@";;
    scan) cmd_scan "$@";;
    reconstruct) cmd_reconstruct "$@";;
    recover) cmd_recover "$@";;
    pipeline) cmd_pipeline "$@";;
    detect-usb) cmd_detect_usb "$@";;
    pipeline-usb) cmd_pipeline_usb "$@";;
    report) cmd_report "$@";;
    demo) cmd_demo "$@";;
    test) cmd_test "$@";;
    --help|-h|help|"") print_usage;;
    *) echo "Unknown command: $cmd" >&2; print_usage; exit 2;;
  esac
}

main "$@"
