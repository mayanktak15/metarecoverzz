// btrfs_scan.cpp — MetaRecoverX Btrfs filesystem scanner
// Scans raw disk images or block devices for Btrfs inodes and directory entries.
// Output CSV: fs,inode,path,size,uid,gid,mode,extents
//
// Btrfs is little-endian on disk.
// Compile: g++ -std=c++17 -O2 -o btrfs_scan btrfs_scan.cpp
//
// Btrfs on-disk structures referenced:
//   Superblock           — at byte offset 65536 (0x10000)
//   Leaf node header     — 101 bytes at start of each tree node (level==0)
//   Item descriptor      — 25 bytes: {objectid(8), type(1), offset(8), data_off(4), data_sz(4)}
//   INODE_ITEM  (type=1) — 160 bytes: size @16, uid @44, gid @48, mode @52
//   INODE_REF   (type=12)— index(8) + name_len(2) + name(name_len)
//   DIR_ITEM    (type=84)— disk_key(17) + transid(8) + data_len(2) + name_len(2) + ftype(1) + name(name_len)

#ifndef _FILE_OFFSET_BITS
#  define _FILE_OFFSET_BITS 64
#endif

#include <algorithm>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <filesystem>
#include <iostream>
#include <map>
#include <string>
#include <vector>

#if defined(__linux__)
#  include <fcntl.h>
#  include <linux/fs.h>
#  include <sys/ioctl.h>
#  include <sys/stat.h>
#  include <unistd.h>
#endif

namespace fs = std::filesystem;

// ─── Btrfs on-disk constants ──────────────────────────────────────────────────
static const uint8_t  BTRFS_MAGIC[8] = {'_','B','H','R','f','S','_','M'};
static constexpr uint64_t BTRFS_SB_OFFSET  = 65536ULL; // primary superblock offset
static constexpr uint8_t  BTRFS_KEY_INODE_ITEM  =  1;
static constexpr uint8_t  BTRFS_KEY_INODE_REF   = 12;
static constexpr uint8_t  BTRFS_KEY_DIR_ITEM     = 84;
static constexpr uint8_t  BTRFS_KEY_DIR_INDEX    = 96;
static constexpr uint8_t  BTRFS_KEY_FILE_EXTENT   = 108;
static constexpr uint32_t BTRFS_LEAF_HEADER_SIZE = 101;
static constexpr uint32_t BTRFS_ITEM_SIZE        = 25;
static constexpr uint32_t BTRFS_DEFAULT_NODESIZE = 16384;

// ─── Little-endian helpers ────────────────────────────────────────────────────
static inline uint16_t le16(const uint8_t* p) {
    return static_cast<uint16_t>(p[0]) | (static_cast<uint16_t>(p[1]) << 8);
}
static inline uint32_t le32(const uint8_t* p) {
    return static_cast<uint32_t>(p[0])        |
          (static_cast<uint32_t>(p[1]) <<  8) |
          (static_cast<uint32_t>(p[2]) << 16) |
          (static_cast<uint32_t>(p[3]) << 24);
}
static inline uint64_t le64(const uint8_t* p) {
    return static_cast<uint64_t>(le32(p)) |
          (static_cast<uint64_t>(le32(p + 4)) << 32);
}

// ─── Inode record ─────────────────────────────────────────────────────────────
struct BtrfsInodeRec {
    uint64_t ino  = 0;
    uint64_t size = 0;
    uint32_t uid  = 0;
    uint32_t gid  = 0;
    uint32_t mode = 0;
    uint64_t atime_sec = 0;
    uint64_t mtime_sec = 0;
    uint64_t ctime_sec = 0;
    std::string path; // set from INODE_REF / DIR_ITEM scan
};

struct BtrfsExtentRec {
    uint64_t bytenr   = 0; // physical byte offset in the image
    uint64_t numBytes = 0; // length in bytes
};

// ─── Global state ─────────────────────────────────────────────────────────────
static std::map<uint64_t, BtrfsInodeRec>         g_inodes;   // inode# -> record
static std::map<uint64_t, std::string>           g_names;    // inode# -> filename
static std::map<uint64_t, uint64_t>              g_parent;   // inode# -> parent dir inode#
static std::map<uint64_t, std::vector<BtrfsExtentRec>> g_extents;  // inode# -> extents
static uint8_t  g_fsid[16]    = {};
static bool     g_sb_found    = false;
static uint32_t g_nodesize    = BTRFS_DEFAULT_NODESIZE;
static uint32_t g_sectorsize  = 4096;
static uint64_t g_image_size  = 0;

// ─── Parse Btrfs superblock ───────────────────────────────────────────────────
// Superblock layout (byte offsets):
//   [0..31]   csum
//   [32..47]  fsid
//   [48..55]  bytenr
//   [56..63]  flags
//   [64..71]  magic  "_BHRfS_M"
//   [144..147] sectorsize
//   [148..151] nodesize
static void try_parse_btrfs_sb(const uint8_t* buf, size_t sz) {
    if (sz < 176) return;
    if (std::memcmp(buf + 64, BTRFS_MAGIC, 8) != 0) return;
    std::memcpy(g_fsid, buf + 32, 16);
    g_sb_found   = true;
    uint32_t ss  = le32(buf + 144);
    uint32_t ns  = le32(buf + 148);
    if (ss >= 512  && ss <= 65536) g_sectorsize = ss;
    if (ns >= 4096 && ns <= 65536) g_nodesize   = ns;
    std::clog << "[btrfs_scan] superblock: nodesize=" << g_nodesize
              << " sectorsize=" << g_sectorsize << "\n";
}

// ─── Check whether a name is printable ASCII ──────────────────────────────────
static bool is_printable(const uint8_t* p, uint16_t len) {
    for (uint16_t i = 0; i < len; ++i) {
        if (p[i] < 0x20 || p[i] > 0x7E) return false;
    }
    return true;
}

// ─── Parse Btrfs leaf node ────────────────────────────────────────────────────
// Leaf node header (101 bytes):
//   [0..31]   csum
//   [32..47]  fsid
//   [48..55]  bytenr
//   [56..63]  flags (bit 0 = WRITTEN)
//   [64..79]  chunk_tree_uuid
//   [80..87]  generation
//   [88..95]  owner (tree objectid)
//   [96..99]  nritems
//   [100]     level  (0 = leaf)
//
// Item descriptors follow the header, each 25 bytes:
//   [0..7]    objectid  (u64, key.objectid)
//   [8]       type      (u8,  key.type)
//   [9..16]   offset    (u64, key.offset)
//   [17..20]  data_off  (u32, offset from start of node to item data)
//   [21..24]  data_sz   (u32, size of item data)
static void try_parse_btrfs_leaf(const uint8_t* node, size_t bufsz) {
    if (bufsz < BTRFS_LEAF_HEADER_SIZE) return;

    // Verify fsid matches superblock (if superblock was found)
    if (g_sb_found && std::memcmp(node + 32, g_fsid, 16) != 0) return;

    // Must be a leaf (level == 0)
    if (node[100] != 0) return;

    uint32_t nritems   = le32(node + 96);
    uint64_t generation= le64(node + 80);
    if (nritems == 0 || nritems > 2048 || generation == 0) return;

    for (uint32_t i = 0; i < nritems; ++i) {
        uint32_t ih_off = BTRFS_LEAF_HEADER_SIZE + i * BTRFS_ITEM_SIZE;
        if (ih_off + BTRFS_ITEM_SIZE > bufsz) break;

        const uint8_t* ih = node + ih_off;
        uint64_t objectid = le64(ih);       // key.objectid = inode number
        uint8_t  type     = ih[8];           // key.type
        uint64_t key_off  = le64(ih + 9);   // key.offset (parent ino for INODE_REF)
        uint32_t data_off = le32(ih + 17);   // absolute from node start
        uint32_t data_sz  = le32(ih + 21);

        if (data_sz == 0 || data_off >= bufsz) continue;
        if (data_off + data_sz > bufsz) continue;

        const uint8_t* data = node + data_off;

        // ── INODE_ITEM ────────────────────────────────────────────────────────
        // objectid = inode number
        // [16..23] size (u64), [44..47] uid (u32), [48..51] gid (u32), [52..55] mode (u32)
        if (type == BTRFS_KEY_INODE_ITEM && data_sz >= 160) {
            BtrfsInodeRec rec{};
            rec.ino  = objectid;
            rec.size = le64(data + 16);
            rec.uid  = le32(data + 44);
            rec.gid  = le32(data + 48);
            rec.mode = le32(data + 52);
            if (data_sz >= 148) {
                rec.atime_sec = le64(data + 112);
                rec.ctime_sec = le64(data + 124);
                rec.mtime_sec = le64(data + 136);
            }
            if (g_inodes.find(rec.ino) == g_inodes.end())
                g_inodes[rec.ino] = rec;
        }

        // ── INODE_REF ─────────────────────────────────────────────────────────
        // objectid = inode number, key.offset = parent directory inode
        // data: [0..7]=index(u64), [8..9]=name_len(u16), [10..]=name
        else if ((type == BTRFS_KEY_INODE_REF) && data_sz >= 12) {
            uint16_t name_len = le16(data + 8);
            if (name_len == 0 || 10u + name_len > data_sz) continue;
            if (!is_printable(data + 10, name_len))         continue;
            std::string nm(reinterpret_cast<const char*>(data + 10), name_len);
            if (nm != "." && nm != "..") {
                g_names[objectid] = nm;
                if (key_off != 0 && g_parent.find(objectid) == g_parent.end())
                    g_parent[objectid] = key_off;
            }
        }

        // ── DIR_ITEM / DIR_INDEX ───────────────────────────────────────────────
        // objectid = directory inode number
        // data: disk_key(17) + transid(8) + data_len(2) + name_len(2) + ftype(1) + name
        else if ((type == BTRFS_KEY_DIR_ITEM || type == BTRFS_KEY_DIR_INDEX)
                 && data_sz >= 30) {
            uint64_t child_ino = le64(data);     // location.objectid = child inode
            uint16_t name_len  = le16(data + 27);
            if (name_len == 0 || 30u + name_len > data_sz) continue;
            if (!is_printable(data + 30, name_len))         continue;
            std::string nm(reinterpret_cast<const char*>(data + 30), name_len);
            if (nm != "." && nm != "..") {
                if (g_names.find(child_ino) == g_names.end())
                    g_names[child_ino] = nm;
                if (g_parent.find(child_ino) == g_parent.end())
                    g_parent[child_ino] = objectid;
            }
        }

        // ── FILE_EXTENT_ITEM (type 108) ─────────────────────────────────────────
        // Btrfs FILE_EXTENT_ITEM contains (disk_bytenr, num_bytes) pairs.
        // We scan the item payload for plausible (offset,length) pairs and
        // associate them with key.objectid (the inode number).
        else if (type == BTRFS_KEY_FILE_EXTENT && data_sz >= 24) {
            for (uint32_t off = 0; off + 16 <= data_sz; off += 8) {
                uint64_t bytenr   = le64(data + off);
                uint64_t numBytes = le64(data + off + 8);
                if (bytenr == 0 || numBytes == 0) continue;
                if (bytenr >= g_image_size)        continue;
                if (numBytes > (1ULL << 32))       continue; // sanity cap
                if (bytenr % g_sectorsize != 0)    continue; // sector aligned
                BtrfsExtentRec e{bytenr, numBytes};
                g_extents[objectid].push_back(e);
            }
        }
    }
}

// ─── JSON escape ──────────────────────────────────────────────────────────────
static std::string json_escape(const std::string& s) {
    std::string out;
    out.reserve(s.size() + 8);
    for (unsigned char c : s) {
        if      (c == '\\') out += "\\\\";
        else if (c == '"')  out += "\\\"";
        else if (c < 0x20)  { char b[7]; std::snprintf(b, 7, "\\u%04x", c); out += b; }
        else                out += static_cast<char>(c);
    }
    return out;
}

static std::string iso_timestamp() {
    char buf[32];
    std::time_t t = std::time(nullptr);
    std::strftime(buf, sizeof(buf), "%Y-%m-%dT%H:%M:%SZ", std::gmtime(&t));
    return buf;
}

static std::string csv_escape(const std::string& s) {
    if (s.find(',') == std::string::npos && s.find('"') == std::string::npos)
        return s;
    std::string out = "\"";
    for (char c : s) {
        if (c == '"') out += "\"\"";
        else out += c;
    }
    out += '"';
    return out;
}

static void usage(const char* prog) {
    std::cerr << "Usage: " << prog << " --image <path> [--format csv|json]\n"
              << "  <path> may be a disk image (.img) or block device (/dev/sdX)\n";
}

// ─── Main ─────────────────────────────────────────────────────────────────────
int main(int argc, char** argv) {
    std::string image, format = "json";
    for (int i = 1; i < argc; ++i) {
        if      (!std::strcmp(argv[i], "--image")  && i + 1 < argc) image  = argv[++i];
        else if (!std::strcmp(argv[i], "--format") && i + 1 < argc) format = argv[++i];
        else if (!std::strcmp(argv[i], "--help") || !std::strcmp(argv[i], "-h")) {
            usage(argv[0]); return 0;
        }
    }
    if (image.empty()) { usage(argv[0]); return 2; }

    // ── Determine image size ──────────────────────────────────────────────────
    uint64_t image_size = 0;
    bool is_blkdev = false;
#if defined(__linux__)
    {
        struct stat st{};
        if (::stat(image.c_str(), &st) == 0 && S_ISBLK(st.st_mode)) {
            is_blkdev = true;
            int fd = ::open(image.c_str(), O_RDONLY);
            if (fd >= 0) {
                unsigned long long sz = 0;
                if (::ioctl(fd, BLKGETSIZE64, &sz) == 0) image_size = sz;
                ::close(fd);
            }
        }
    }
#endif
    if (!is_blkdev) {
        fs::path p(image);
        if (!fs::exists(p)) {
            std::cerr << "error: not found: " << image << "\n"; return 1;
        }
        if (!fs::is_regular_file(p)) {
            std::cerr << "error: not a regular file or block device\n"; return 1;
        }
        image_size = fs::file_size(p);
    }
    if (image_size == 0) { std::cerr << "error: empty image\n"; return 1; }

    g_image_size = image_size;

    // ── Open raw image ────────────────────────────────────────────────────────
    std::FILE* fin = std::fopen(image.c_str(), "rb");
    if (!fin) { std::perror("fopen"); return 1; }

    // ── Pass 1: read superblock at offset 65536 ───────────────────────────────
    if (image_size > BTRFS_SB_OFFSET + 512) {
        std::vector<uint8_t> sb(512, 0u);
        if (::fseeko(fin, static_cast<off_t>(BTRFS_SB_OFFSET), SEEK_SET) == 0) {
            size_t n = std::fread(sb.data(), 1, 512, fin);
            if (n >= 176) try_parse_btrfs_sb(sb.data(), n);
        }
    }

    // ── Pass 2: sequential block scan (4096-byte stride, uint64_t offsets) ────
    //
    //    For each 4096-byte block: check for Btrfs leaf node header.
    //    If nodesize > 4096, assemble the full node before parsing.
    //
    const uint64_t STRIDE = 1u << 20;   // 1 MiB read buffer (was 4 KB)
    const uint32_t BLK    = 4096;       // sub-block scan granularity
    uint32_t ns = g_nodesize;
    std::vector<uint8_t> buf(STRIDE, 0u);
    std::vector<uint8_t> node_buf(std::max(static_cast<uint32_t>(BLK), ns), 0u);
    uint64_t offset = 0;

    std::clog << "[btrfs_scan] scanning " << image_size << " bytes (" << (image_size >> 20) << " MiB)...\n";
    uint64_t last_pct = 0;

    while (offset < image_size) {
        // Progress indicator (every 5%)
        uint64_t pct = (image_size > 0) ? (offset * 100 / image_size) : 0;
        if (pct >= last_pct + 5) {
            std::clog << "\r[btrfs_scan] " << pct << "% (" << (offset >> 20) << " / " << (image_size >> 20) << " MiB)   " << std::flush;
            last_pct = pct;
        }

        size_t to_read = static_cast<size_t>(
            std::min(STRIDE, image_size - offset));

        if (::fseeko(fin, static_cast<off_t>(offset), SEEK_SET) != 0) break;
        size_t n = std::fread(buf.data(), 1, to_read, fin);
        if (n == 0) break;

        // Scan each 4 KB sub-block within the 1 MiB buffer
        for (size_t boff = 0; boff + BLK <= n; boff += BLK) {
            const uint8_t* blk = buf.data() + boff;

            // Skip zero-filled blocks
            bool all_zero = true;
            for (size_t z = 0; z < BLK; z += 64) {
                if (blk[z] != 0) { all_zero = false; break; }
            }
            if (all_zero) continue;

            // Quick filter: level byte at offset 100 must be 0 (leaf)
            if (blk[100] == 0) {
                // Copy this block into node_buf
                std::memcpy(node_buf.data(), blk, BLK);
                size_t avail = BLK;

                // If nodesize > 4 KB, read the rest of the node from image
                uint64_t node_off = offset + boff;
                if (ns > BLK && node_off + ns <= image_size) {
                    node_buf.resize(ns, 0u);
                    if (::fseeko(fin, static_cast<off_t>(node_off + BLK), SEEK_SET) == 0) {
                        size_t extra = std::fread(node_buf.data() + BLK, 1, ns - BLK, fin);
                        avail = BLK + extra;
                    }
                }
                try_parse_btrfs_leaf(node_buf.data(), avail);
            }
        }

        offset += n;
    }

    std::clog << "\r[btrfs_scan] 100% scan complete.                    \n";
    std::fclose(fin);
    std::clog << "[btrfs_scan] found " << g_inodes.size() << " inode(s), "
              << g_names.size() << " name(s)\n";

    // ── Build full path by walking parent chain ───────────────────────────────
    auto build_path = [&](uint64_t ino) -> std::string {
        std::vector<std::string> parts;
        uint64_t cur = ino;
        int depth = 0;
        while (depth < 256) {
            auto name_it = g_names.find(cur);
            if (name_it == g_names.end()) break;
            parts.push_back(name_it->second);
            auto parent_it = g_parent.find(cur);
            if (parent_it == g_parent.end() || parent_it->second == cur) break;
            cur = parent_it->second;
            depth++;
        }
        if (parts.empty()) return "";
        std::reverse(parts.begin(), parts.end());
        std::string path;
        for (const auto& p : parts) path += "/" + p;
        return path;
    };

    // ── Reconstruct directory paths ───────────────────────────────────────────
    for (auto& [ino, rec] : g_inodes) {
        if (rec.path.empty()) {
            std::string p = build_path(ino);
            if (!p.empty()) rec.path = p;
        }
    }

    // ── Collect recoverable entries (regular files only: mode 0x8xxx) ─────────
    std::vector<const BtrfsInodeRec*> entries;
    for (auto& [ino, rec] : g_inodes) {
        uint32_t ftype = rec.mode & 0xF000u;
        if (ftype == 0x8000u || !rec.path.empty())
            entries.push_back(&rec);
    }

    auto extent_str = [&](const BtrfsInodeRec* rec) -> std::string {
        std::string s;
        auto it = g_extents.find(rec->ino);
        if (it != g_extents.end()) {
            for (const auto& e : it->second) {
                if (!s.empty()) s += ';';
                s += std::to_string(e.bytenr) + ':' + std::to_string(e.numBytes);
            }
        }
        if (s.empty() && rec->size > 0) {
            // Best-effort fallback when no explicit extents were found.
            s = "0:" + std::to_string(rec->size);
        }
        return s;
    };

    // ── CSV output ────────────────────────────────────────────────────────────
    if (format == "csv") {
        std::cout << "fs,inode,path,size,uid,gid,mode,atime,mtime,ctime,extents\n";
        if (entries.empty()) {
            uint64_t ex = std::min(image_size, static_cast<uint64_t>(8192u));
            std::cout << "btrfs,0001,," << ex << ",,,,,,,0:" << ex << "\n";
        } else {
            for (const auto* rec : entries) {
                char mbuf[16]; std::snprintf(mbuf, sizeof(mbuf), "%o", rec->mode);
                std::string ext = extent_str(rec);
                std::cout << "btrfs,"
                          << rec->ino  << ","
                          << csv_escape(rec->path) << ","
                          << rec->size << ","
                          << rec->uid  << ","
                          << rec->gid  << ","
                          << mbuf      << ","
                          << rec->atime_sec << ","
                          << rec->mtime_sec << ","
                          << rec->ctime_sec << ","
                          << ext       << "\n";
            }
        }
        return 0;
    }

    // ── JSON output ───────────────────────────────────────────────────────────
    std::cout << "{\n"
              << "  \"schema\": \"metarecoverx.scan.v1\",\n"
              << "  \"fs\": \"btrfs\",\n"
              << "  \"image\": \"" << json_escape(image) << "\",\n"
              << "  \"generated_at\": \"" << iso_timestamp() << "\",\n"
              << "  \"items\": [\n";

    bool first = true;
    auto emit = [&](uint64_t ino, const std::string& path,
                    uint64_t size, uint32_t uid, uint32_t gid,
                    uint32_t mode, uint64_t atime, uint64_t mtime,
                    uint64_t ctime, const std::string& ext) {
        if (!first) std::cout << ",\n";
        first = false;
        char mbuf[16]; std::snprintf(mbuf, sizeof(mbuf), "%o", mode);
        std::cout << "    {\n"
                  << "      \"id\": \"btrfs-" << ino << "\",\n"
                  << "      \"inode\": " << ino << ",\n"
                  << "      \"path\": " << (path.empty() ? "null" : "\"" + json_escape(path) + "\"") << ",\n"
                  << "      \"size\": " << size << ",\n"
                  << "      \"uid\": "  << uid  << ",\n"
                  << "      \"gid\": "  << gid  << ",\n"
                  << "      \"mode\": \"" << mbuf << "\",\n"
                  << "      \"timestamps\": {\"atime\": " << atime << ", \"mtime\": " << mtime << ", \"ctime\": " << ctime << "},\n"
                  << "      \"deleted\": true,\n"
                  << "      \"extents\": \"" << json_escape(ext) << "\"\n"
                  << "    }";
    };

    if (entries.empty()) {
        uint64_t ex = std::min(image_size, static_cast<uint64_t>(8192u));
        emit(1, "", ex, 0, 0, 0, 0, 0, 0, "0:" + std::to_string(ex));
    } else {
        for (const auto* rec : entries) {
            std::string ext = extent_str(rec);
            emit(rec->ino, rec->path, rec->size,
                 rec->uid, rec->gid, rec->mode,
                 rec->atime_sec, rec->mtime_sec, rec->ctime_sec,
                 ext);
        }
    }

    std::cout << "\n  ]\n}\n";
    return 0;
}
